#ifndef HTTPSERVER_H
#define HTTPSERVER_H

/*----Libraries--------------------------*/


/*----Constants--------------------------*/


/*----Shared Globals---------------------*/


/*----Custom Data Types------------------*/


/*----Function Prototypes----------------*/
// print out program usage to console
void usage();

#endif