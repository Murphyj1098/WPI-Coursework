The project can be compiled by running make in the root directory (the same directory as this readme)

The project can be run by running ./project2 in the root directory (the same directory as this readme)
    The project will then run and ask for the emulation arguments

Running at TraceLevel 2 will show my created debug statements, colored for easier reading

The program was tested with an average time between messages of 1000