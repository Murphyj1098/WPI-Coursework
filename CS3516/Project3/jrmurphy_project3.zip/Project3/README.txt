The project can be compiled by running make in the root directory (the same directory as this readme)

The project can be run by running "./project3 1" in the root directory (the same directory as this readme)

The program will then output the emulator's trace